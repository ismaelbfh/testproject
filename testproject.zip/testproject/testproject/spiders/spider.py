import sys
import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from testproject.items import TestprojectItem
from scrapy.exceptions import CloseSpider

class TestprojectSpider(CrawlSpider):
	name = 'testproject'
	item_count = 0
	allowed_domain = ['www.mercadolibre.com.mx']
	start_urls = ['http://listado.mercadolibre.com.mx/impresoras#D[A:impresoras]']

	rules = {

		Rule(LinkExtractor(allow = (), restrict_xpaths = ('//li[@class="andes-pagination__button andes-pagination__button--next"]'))),
		Rule(LinkExtractor(allow = (), restrict_xpaths = ('//h2[@class="ui-search-item__title"]')),
							callback = 'parse_item', follow = False)
	}

def parse_item(self, response):
	ml_item = TestprojectItem()

	#info de producto
	ml_item['titulo'] = response.xpath('normalize-space(/html/body/main/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/h1/text())').extract_first();
	ml_item['folio'] = response.xpath('normalize-space(//*[@id="root-app"]/div[2]/div[1]/div/div[1]/div[1]/ul/li[5]/a/text())').extract();
	ml_item['precio'] = response.xpath('normalize-space(/html/body/main/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div/span[1]/span[2]/text())').extract();
	ml_item['condicion'] = response.xpath('normalize-space(//*[@id="root-app"]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/span/text())').extract();
	ml_item['envio'] = response.xpath('normalize-space(//h2[@class="ui-pdp-color--GREEN ui-pdp-media__title"]/text())').extract();
	ml_item['ubicacion'] = response.xpath('normalize-space(//h2[@class="ui-pdp-color--GREEN ui-pdp-media__title"]/text())').extract();
	ml_item['opiniones'] = response.xpath('normalize-space(//h2[@class="ui-pdp-reviews__rating__summary__average"]/text())').extract();
	ml_item['ventas_producto'] = response.xpath('normalize-space(//*[@id="root-app"]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/span/text())').extract();
	

	#info vendedor
	ml_item['vendedor_url'] = response.xpath('normalize-space(//*[@id="root-app"]/div[2]/div[2]/div[1]/div[2]/div[1]/form/div[2]/div/div/h3/div/a/text())').extract();
	ml_item['tipo_vendedor'] = response.xpath('normalize-space(//*[contains(@class, "ui-pdp-size--XSMALL ui-pdp-family--REGULAR ui-pdp-seller__header__subtitle")]/text())').extract();
	ml_item['reputacion'] = response.xpath('normalize-space(//*[contains(@class, "ui-pdp-promotions-pill__label ui-pdp-background-color--ORANGE")]/text())').extract();
	ml_item['ventas_vendedor'] = response.xpath('normalize-space(//*[@id="root-app"]/div[2]/div[2]/div[1]/div[2]/div[1]/form/div[2]/div/div/p/text())').extract();
	self.item_count += 1
	if self.item_count > 2:
		raise CloseSpider('Item exceeded')
	yield ml_item
